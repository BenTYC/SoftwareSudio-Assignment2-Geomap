package netdb.courses.softwarestudio.geomap.spatial;

/**
 * A point in a geometric space.
 */
public class Point extends Shape {
	private double[] coordinates;

	public Point(double[] coordinates) {
		if (coordinates.length < 1)
			throw new IllegalArgumentException();
		this.coordinates = new double[coordinates.length];
		System.arraycopy(coordinates, 0, this.coordinates, 0,
				coordinates.length);
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this)
			return true;

		if (!(obj instanceof Point))
			return false;
		Point p = (Point) obj;
		if (p.coordinates.length != coordinates.length)
			return false;
		for (int i = 0; i < coordinates.length; i++) {
			if (Double.compare(p.coordinates[i], coordinates[i]) != 0)
				return false;
		}
		return true;
	}

	@Override
	public String toString() {
		StringBuffer ret = new StringBuffer("Point@{");
		for (int i = 0; i < coordinates.length; i++) {
			if (i > 0)
				ret.append(", ");
			ret.append(coordinates[i]);
		}
		ret.append("}");
		return ret.toString();
	}

	public double getCoordinate(int dim) {
		return coordinates[dim];
	}

	public int getDimension() {
		return coordinates.length;
	}

	public double getVolume() {
		return 0;
	}
	
	@Override
	public boolean isIntersect(Rectangle rec) {
		return this.getCoordinate(0) >= rec.getLower().getCoordinate(0)
				&& this.getCoordinate(0) <= rec.getUpper().getCoordinate(0)
				&& this.getCoordinate(1) >= rec.getLower().getCoordinate(1)
				&& this.getCoordinate(1) <= rec.getUpper().getCoordinate(1);
	}
	
	@Override
	public double getDistance(Point p) {
		return Math.sqrt((this.getCoordinate(0) - p.getCoordinate(0))
				* (this.getCoordinate(0) - p.getCoordinate(0))
				+ (this.getCoordinate(1) - p.getCoordinate(1))
				* (this.getCoordinate(1) - p.getCoordinate(1)));
	}

}
