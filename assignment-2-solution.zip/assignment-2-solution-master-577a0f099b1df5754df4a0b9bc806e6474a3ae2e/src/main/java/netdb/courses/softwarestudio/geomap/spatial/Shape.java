package netdb.courses.softwarestudio.geomap.spatial;

/**
 * A shape in a geometric space.
 * 
 */
public abstract class Shape implements Geometric {

	public String getSpaceName() {
		return "Euclidean Space";
	}
	
	/**
	 * Checks if this shape overlaps the specified rectangle.
	 * 
	 * @param rec
	 * @return
	 */
	public abstract boolean isIntersect(Rectangle rec);
	
	/**
	 * Calculates the distance between this shape and the specified point.
	 * 
	 * @param p
	 * @return
	 */
	public abstract double getDistance(Point p);

}
