package netdb.courses.softwarestudio.geomap.map;

import java.util.LinkedList;

import netdb.courses.softwarestudio.geomap.spatial.Shape;

/**
 * Stores k-nearest shapes to a point ascendingly based on their distances.
 */
public class OrderedKnnResults {
	/**
	 * Internal storage that keeps the result shapes.
	 */
	private LinkedList<KnnResultElement> results;
	
	/**
	 * Number of shapes we want.
	 */
	private int k;
	
	public OrderedKnnResults(int k) {
		this.results = new LinkedList<KnnResultElement>();
		this.k = k;
	}
	
	/**
	 * The specified shape is added into the results only if it is one of the 
	 * k-nearest shapes currently.
	 * 
	 * @param s
	 * @param distance
	 */
	public void addIfKnn(Shape s, double distance) {
		KnnResultElement newResult = new KnnResultElement(s, distance);
		int insertPosition = -1;
		
		// iterate elements from head to tail
		for (KnnResultElement result : results) {
			// if new element is closer, it should be insert here
			if (result.getDistance() > newResult.getDistance()) {
				insertPosition = results.indexOf(result);
				break;
			}
		}
		
		// if this element should be inserted to somewhere
		if (insertPosition > -1) {
			results.add(insertPosition, newResult);
			
			// check size
			if (results.size() > k)
				results.pollLast();
		} else if (results.size() < k) // if there is some space, insert it at the end of list
			results.add(newResult);
	}
	
	public Shape[] toArray() {
		Shape[] shapes = new Shape[results.size()];
		
		// copy shapes
		int i = 0;
		for (KnnResultElement result : results) {
			shapes[i] = result.getShape();
			i++;
		}
		
		return shapes;
	}

}
