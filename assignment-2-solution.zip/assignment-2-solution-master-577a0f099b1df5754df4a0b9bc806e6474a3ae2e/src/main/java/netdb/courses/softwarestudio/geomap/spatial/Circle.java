package netdb.courses.softwarestudio.geomap.spatial;

/**
 * A circle in a two-dimensional space.
 */
public class Circle extends Shape {
	private Point center;
	private double radius;

	public Circle(Point center, double radius) {
		if (center.getDimension() != 2)
			throw new IllegalArgumentException();
		this.center = center;
		this.radius = radius;
	}

	@Override
	public String toString() {
		StringBuffer ret = new StringBuffer("Circle@{");
		ret.append(center.toString());
		ret.append(", " + radius + "}");
		return ret.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this)
			return true;

		if (!(obj instanceof Circle))
			return false;
		Circle c = (Circle) obj;
		return c.center.equals(center) && Double.compare(c.radius, radius) == 0;
	}

	@Override
	public double getVolume() {
		return Math.PI * radius * radius;
	}
	
	@Override
	public boolean isIntersect(Rectangle rec) {
		if(rec.getDistance(center) <= radius)
			return true;
		return false;
	}
	
	@Override
	public double getDistance(Point p) {
		double dist = p.getDistance(center) - radius;
		return dist <= 0 ? 0 : dist;
	}

}
