package netdb.courses.softwarestudio.geomap.map;

import netdb.courses.softwarestudio.geomap.spatial.Shape;

public class KnnResultElement {
	private Shape shape;
	private double distance;
	
	public KnnResultElement(Shape shape, double distance) {
		this.shape = shape;
		this.distance = distance;
	}

	public Shape getShape() {
		return shape;
	}

	public double getDistance() {
		return distance;
	}

}
