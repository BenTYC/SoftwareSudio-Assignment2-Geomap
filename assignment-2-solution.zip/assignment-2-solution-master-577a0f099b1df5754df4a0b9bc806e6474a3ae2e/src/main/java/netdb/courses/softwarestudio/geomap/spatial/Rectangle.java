package netdb.courses.softwarestudio.geomap.spatial;

/**
 * A 2D rectangle in a geometric space.
 */
public class Rectangle extends Shape {
	protected Point lower;
	protected Point upper;

	public Rectangle(Point lower, Point upper) {
		if (lower.getDimension() != 2
				|| lower.getDimension() != upper.getDimension())
			throw new IllegalArgumentException();
		this.lower = lower;
		this.upper = upper;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this)
			return true;

		if (!(obj instanceof Rectangle))
			return false;
		Rectangle rec = (Rectangle) obj;
		return rec.lower.equals(lower) && rec.upper.equals(upper);
	}

	@Override
	public String toString() {
		StringBuffer ret = new StringBuffer("Rectangle@{");
		ret.append(lower.toString());
		ret.append(", " + upper.toString() + "}");
		return ret.toString();
	}
	
	public Point getLower() {
		return lower;
	}

	public Point getUpper() {
		return upper;
	}

	public double getSide(int dim) {
		return upper.getCoordinate(dim) - lower.getCoordinate(dim);
	}

	@Override
	public double getVolume() {
		double sum = 1d;
		for (int i = 0; i < upper.getDimension(); i++) {
			sum *= getSide(i);
		}
		return sum;
	}
	
	/**
	 * Two rectangles overlap iff their ranges overlap in each dimension. 
	 */
	@Override
	public boolean isIntersect(Rectangle rec) {
		return isIntersect(lower.getCoordinate(0), upper.getCoordinate(0),
				rec.lower.getCoordinate(0), rec.upper.getCoordinate(0))
				&& isIntersect(lower.getCoordinate(1), upper.getCoordinate(1),
						rec.lower.getCoordinate(1), rec.upper.getCoordinate(1));
	}
	
	@Override
	public double getDistance(Point p) {
		// upper left coordinates
		double[] ulc = { upper.getCoordinate(0), lower.getCoordinate(1) };
		// lower right coordinates
		double[] lrc = { lower.getCoordinate(0), upper.getCoordinate(1) };
		
		// get quadrant
		int quadrant = getQuadrant(p);
		
		// use different methods to measure distance according to its quadrant
		if((quadrant == 1))
			return p.getDistance(new Point(ulc));
		else if((quadrant == 3))
			return p.getDistance(upper);
		else if((quadrant == 7))
			return p.getDistance(lower);
		else if((quadrant == 9))
			return p.getDistance(new Point(lrc));
		else if((quadrant == 2))
			return p.getCoordinate(1) - upper.getCoordinate(1);
		else if((quadrant == 4))
			return lower.getCoordinate(0) - p.getCoordinate(0);
		else if((quadrant == 6))
			return p.getCoordinate(0) - upper.getCoordinate(0);
		else if((quadrant == 8))
			return lower.getCoordinate(1) - p.getCoordinate(1);
		return 0;
	}
	
	/**
	 * Calculates the index of an 3 by 3 grid partitioned by this rectangle 
	 * inside which the point falls. The 3 by 3 grid is partitioned as follows:
	 * 
	 *     1    |    2    |    3
	 * ---------+---------+----------
	 *     4    |  5(Rec) |    6
	 * ---------+---------+----------
	 *     7    |    8    |    9
	 * 
	 * @param p
	 * @return
	 */
	private int getQuadrant(Point p) {
		// get boundaries
		double leftSideX = lower.getCoordinate(0);
		double rightSideX = upper.getCoordinate(0);
		double upSideY = upper.getCoordinate(1);
		double downSideY = lower.getCoordinate(1);
		
		// get point coordinates
		double pX = p.getCoordinate(0);
		double pY = p.getCoordinate(1);
		
		// find quadrant
		if(pX < leftSideX && pY > upSideY)
			return 1;
		else if(pX >= leftSideX && pX <= rightSideX	&& pY > upSideY)
			return 2;
		else if(pX > rightSideX	&& pY > upSideY)
			return 3;
		else if(pX < leftSideX && pY >= downSideY && pY <= upSideY)
			return 4;
		else if(pX > rightSideX && pY >= downSideY && pY <= upSideY)
			return 6;
		else if(pX < leftSideX && pY < downSideY)
			return 7;
		else if(pX >= leftSideX && pX <= rightSideX && pY < downSideY)
			return 8;
		else if(pX > rightSideX	&& pY < downSideY)
			return 9;
		else
			return 5;
	}
	
	/**
	 * Test whether two ranges overlap.
	 * 
	 * There are two cases these two ranges that will not overlap.
	 * 
	 * Case 1:
	 * low1           high1
	 *  |---------------|  low2    high2
	 *                      |-------|
	 * 
	 * 
	 * Case 2:
	 *             low1          high1
	 * low2   high2 |--------------|
	 *  |-------|
	 * 
	 * We just need to check these cases.
	 * 
	 * @param low1
	 * @param high1
	 * @param low2
	 * @param high2
	 * @return
	 */
	private boolean isIntersect(double low1, double high1, double low2,
			double high2) {
		return !(low2 > high1 || low1 > high2);
	}
}
