package netdb.courses.softwarestudio.geomap.map;

import java.util.ArrayList;
import java.util.List;

import netdb.courses.softwarestudio.geomap.spatial.Point;
import netdb.courses.softwarestudio.geomap.spatial.Rectangle;
import netdb.courses.softwarestudio.geomap.spatial.Shape;

public class GeoMapImpl implements GeoMap {
	
	/**
	 * Internal storage that keeps the added shapes.
	 */
	private List<Shape> shapes;
	
	public GeoMapImpl() {
		// each element is initiated as null
		shapes = new ArrayList<Shape>();
	}

	@Override
	public void addShape(Shape s) {
		if (s != null)
			shapes.add(s);
	}

	@Override
	public void addShapes(Shape[] ss) {
		for(Shape s : ss)
			addShape(s);
	}

	@Override
	public Shape[] rangeQuery(Rectangle rec) {
		List<Shape> results = new ArrayList<Shape>();
		
		for(Shape s : shapes) {
			/* 
			 * Polymorphism: the right version of isIntersect() will be 
			 * determined at run time
			 */
			if(s.isIntersect(rec)) 
				results.add(s);
		}
		
		if(results.size() == 0)
			return null;
		return results.toArray(new Shape[0]);
	}

	@Override
	public Shape[] knnQuery(Point p, int k) {
		if(shapes.size() == 0)
			return null;
		
		OrderedKnnResults ors = new OrderedKnnResults(k);
		for(Shape s : shapes) {
			/* 
			 * Polymorphism: the right version of getDistance() will be 
			 * determined at run time
			 */
			ors.addIfKnn(s, s.getDistance(p));
		}
		return ors.toArray();
	}

}
